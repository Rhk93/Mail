package it.paolicelli.mail;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Salva i dati dell'account cifrati con AES-256 (chiave nel Keystore di Android, non estraibile). */
class Cassaforte {
    private static final String ALIAS = "mail_chiave";
    private final SharedPreferences sp;

    Cassaforte(Context c) { sp = c.getSharedPreferences("cassaforte", Context.MODE_PRIVATE); }

    private SecretKey chiave() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(ALIAS)) return ((KeyStore.SecretKeyEntry) ks.getEntry(ALIAS, null)).getSecretKey();
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(new KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build());
        return kg.generateKey();
    }

    void scrivi(String s) throws Exception {
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.ENCRYPT_MODE, chiave());
        byte[] iv = c.getIV();
        byte[] ct = c.doFinal(s.getBytes(StandardCharsets.UTF_8));
        byte[] tot = new byte[iv.length + ct.length];
        System.arraycopy(iv, 0, tot, 0, iv.length);
        System.arraycopy(ct, 0, tot, iv.length, ct.length);
        sp.edit().putString("dati", Base64.encodeToString(tot, Base64.NO_WRAP)).apply();
    }

    String leggi() throws Exception {
        String d = sp.getString("dati", null);
        if (d == null) return null;
        byte[] tot = Base64.decode(d, Base64.NO_WRAP);
        Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
        c.init(Cipher.DECRYPT_MODE, chiave(), new GCMParameterSpec(128, tot, 0, 12));
        return new String(c.doFinal(tot, 12, tot.length - 12), StandardCharsets.UTF_8);
    }

    void cancella() { sp.edit().clear().apply(); }
}
