package it.paolicelli.mail;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;

public class MainActivity extends Activity {
    WebView web;
    MailBridge ponte;
    String mailto;
    private ValueCallback<Uri[]> scelta;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        mailto = leggiMailto(getIntent());
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(false);
        s.setTextZoom(100);
        s.setMediaPlaybackRequiresUserGesture(true);

        ponte = new MailBridge(this, web);
        web.addJavascriptInterface(ponte, "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                final String u = r.getUrl().toString();
                if (u.startsWith("file:///android_asset/") || u.startsWith("about:")) return false;
                if (u.startsWith("mailto:")) {
                    v.evaluateJavascript("apriMailto(" + JSONObject.quote(u) + ")", null);
                    return true;
                }
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("Aprire il link?")
                        .setMessage(u)
                        .setNegativeButton("Annulla", null)
                        .setPositiveButton("Apri", (d, w) -> apriEsterno(u))
                        .show();
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                String sc = r.getUrl().getScheme();
                if (("http".equals(sc) || "https".equals(sc)) && !ponte.remoti) {
                    return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
                }
                return null;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (scelta != null) scelta.onReceiveValue(null);
                scelta = cb;
                try {
                    Intent i = p.createIntent();
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(i, 7);
                } catch (Exception e) {
                    scelta = null;
                    return false;
                }
                return true;
            }
        });

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int rq, int rs, Intent d) {
        super.onActivityResult(rq, rs, d);
        if (rq != 7 || scelta == null) return;
        Uri[] r = null;
        if (rs == RESULT_OK && d != null) {
            if (d.getClipData() != null) {
                int n = d.getClipData().getItemCount();
                r = new Uri[n];
                for (int k = 0; k < n; k++) r[k] = d.getClipData().getItemAt(k).getUri();
            } else if (d.getData() != null) {
                r = new Uri[]{d.getData()};
            }
        }
        scelta.onReceiveValue(r);
        scelta = null;
    }

    private String leggiMailto(Intent i) {
        if (i == null || i.getDataString() == null) return null;
        String s = i.getDataString();
        return s.startsWith("mailto:") ? s : null;
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        String m = leggiMailto(i);
        if (m != null) web.evaluateJavascript("apriMailto(" + JSONObject.quote(m) + ")", null);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("typeof riprendi=='function'&&riprendi()", null);
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        web.evaluateJavascript("typeof applicaTema=='function'&&applicaTema()", null);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("indietro()", v -> {
            if (!"true".equals(v)) finish();
        });
    }

    void apriEsterno(String u) {
        Uri uri = Uri.parse(u);
        String s = uri.getScheme();
        if (s == null) return;
        s = s.toLowerCase();
        if (!(s.equals("http") || s.equals("https") || s.equals("tel"))) return;
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (Exception ignored) {
        }
    }

    @SuppressWarnings("deprecation")
    void barra(String c, boolean scuro) {
        try {
            Window w = getWindow();
            int col = Color.parseColor(c);
            w.setStatusBarColor(col);
            w.setNavigationBarColor(col);
            web.setBackgroundColor(col);
            int f = 0;
            if (!scuro) f = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
            w.getDecorView().setSystemUiVisibility(f);
        } catch (Exception ignored) {
        }
    }
}
