package it.paolicelli.mail;

import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import androidx.core.content.FileProvider;

import com.sun.mail.imap.IMAPFolder;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.activation.DataHandler;
import javax.mail.Address;
import javax.mail.AuthenticationFailedException;
import javax.mail.FetchProfile;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Part;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.StoreClosedException;
import javax.mail.Transport;
import javax.mail.UIDFolder;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;
import javax.mail.search.BodyTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.OrTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SubjectTerm;
import javax.mail.util.ByteArrayDataSource;

/** Ponte tra l'interfaccia (HTML) e la posta (IMAP/SMTP solo su connessioni cifrate SSL/TLS). */
public class MailBridge {
    private final MainActivity act;
    private final WebView web;
    private final Cassaforte cassa;
    private final ExecutorService ex = Executors.newSingleThreadExecutor();
    private final ConcurrentHashMap<String, String> risultati = new ConcurrentHashMap<>();
    private final Map<String, IMAPFolder> aperte = new HashMap<>();
    private final Map<String, String> speciali = new HashMap<>();
    private final Map<String, String> anteprime = new HashMap<>();
    private volatile JSONObject acc;
    private Session sessione;
    private Store store;
    volatile boolean remoti = false;

    interface Lavoro { Object fai() throws Exception; }

    static class Cont { String testo, html; List<Part> allegati = new ArrayList<>(); }

    MailBridge(MainActivity a, WebView w) {
        act = a;
        web = w;
        cassa = new Cassaforte(a);
        try {
            String s = cassa.leggi();
            if (s != null) acc = new JSONObject(s);
        } catch (Exception e) {
            acc = null;
        }
    }

    // ---------- esecuzione in background ----------
    private void esegui(String id, Lavoro l) {
        final String cid = id.replaceAll("[^0-9a-zA-Z]", "");
        ex.execute(() -> {
            JSONObject r = new JSONObject();
            try {
                Object v;
                try {
                    v = l.fai();
                } catch (FolderClosedException | StoreClosedException | IllegalStateException e) {
                    chiudiTutto();
                    v = l.fai();
                } catch (MessagingException e) {
                    if (e.getCause() instanceof IOException) {
                        chiudiTutto();
                        v = l.fai();
                    } else throw e;
                }
                r.put("ok", true);
                r.put("dati", v == null ? JSONObject.NULL : v);
            } catch (Throwable t) {
                try {
                    r.put("ok", false);
                    r.put("errore", messaggio(t));
                } catch (JSONException ignored) {
                }
            }
            risultati.put(cid, r.toString());
            act.runOnUiThread(() -> web.evaluateJavascript("__fatto('" + cid + "')", null));
        });
    }

    @JavascriptInterface
    public String risultato(String id) { return risultati.remove(id); }

    private String messaggio(Throwable t) {
        if (t instanceof AuthenticationFailedException)
            return "Accesso non riuscito: email o password errati. Gmail, iCloud e Yahoo richiedono una \"password per le app\".";
        Throwable c = t;
        while (c != null) {
            if (c instanceof java.net.UnknownHostException) return "Server non trovato o nessuna connessione a Internet.";
            if (c instanceof java.net.SocketTimeoutException) return "Il server non risponde. Riprova.";
            if (c instanceof javax.net.ssl.SSLException) return "Connessione sicura non riuscita (certificato non valido).";
            if (c instanceof java.net.ConnectException) return "Impossibile collegarsi al server.";
            c = c.getCause();
        }
        String s = t.getMessage();
        return (s == null || s.isEmpty()) ? t.getClass().getSimpleName() : s;
    }

    // ---------- connessione ----------
    private Properties props(JSONObject a) {
        Properties p = new Properties();
        String t1 = "15000", t2 = "30000";
        p.put("mail.imaps.host", a.optString("imap"));
        p.put("mail.imaps.port", String.valueOf(a.optInt("imapPort", 993)));
        p.put("mail.imaps.ssl.checkserveridentity", "true");
        p.put("mail.imaps.peek", "true");
        p.put("mail.imaps.connectiontimeout", t1);
        p.put("mail.imaps.timeout", t2);
        int sp = a.optInt("smtpPort", 587);
        p.put("mail.smtp.host", a.optString("smtp"));
        p.put("mail.smtp.port", String.valueOf(sp));
        p.put("mail.smtp.auth", "true");
        if (sp == 465) {
            p.put("mail.smtp.ssl.enable", "true");
        } else {
            p.put("mail.smtp.starttls.enable", "true");
            p.put("mail.smtp.starttls.required", "true");
        }
        p.put("mail.smtp.ssl.checkserveridentity", "true");
        p.put("mail.smtp.connectiontimeout", t1);
        p.put("mail.smtp.timeout", t2);
        return p;
    }

    private String utente(JSONObject a) {
        String u = a.optString("utente", "");
        return u.isEmpty() ? a.optString("email") : u;
    }

    private Store store() throws Exception {
        if (acc == null) throw new Exception("Nessun account configurato.");
        if (store != null && store.isConnected()) return store;
        chiudiTutto();
        sessione = Session.getInstance(props(acc));
        Store s = sessione.getStore("imaps");
        s.connect(acc.optString("imap"), acc.optInt("imapPort", 993), utente(acc), acc.optString("password"));
        store = s;
        return s;
    }

    private void chiudiTutto() {
        for (IMAPFolder f : aperte.values()) {
            try { if (f.isOpen()) f.close(false); } catch (Exception ignored) { }
        }
        aperte.clear();
        try { if (store != null) store.close(); } catch (Exception ignored) { }
        store = null;
    }

    private IMAPFolder cartella(String nome) throws Exception {
        Store s = store();
        IMAPFolder f = aperte.get(nome);
        if (f == null || !f.isOpen()) {
            f = (IMAPFolder) s.getFolder(nome);
            f.open(Folder.READ_WRITE);
            aperte.put(nome, f);
        }
        return f;
    }

    private Message msg(IMAPFolder f, String uid) throws Exception {
        Message m = f.getMessageByUID(Long.parseLong(uid));
        if (m == null) throw new Exception("Messaggio non trovato (forse già eliminato).");
        return m;
    }

    // ---------- account ----------
    @JavascriptInterface
    public String account() {
        JSONObject a = acc;
        if (a == null) return "";
        try {
            JSONObject o = new JSONObject();
            o.put("email", a.optString("email"));
            o.put("nome", a.optString("nome"));
            return o.toString();
        } catch (JSONException e) {
            return "";
        }
    }

    @JavascriptInterface
    public void salvaAccount(String id, String json) {
        esegui(id, () -> {
            JSONObject j = new JSONObject(json);
            Session s = Session.getInstance(props(j));
            Store st = s.getStore("imaps");
            st.connect(j.optString("imap"), j.optInt("imapPort", 993), utente(j), j.optString("password"));
            st.close();
            Transport t = s.getTransport("smtp");
            try {
                t.connect(j.optString("smtp"), j.optInt("smtpPort", 587), utente(j), j.optString("password"));
            } catch (MessagingException e) {
                throw new Exception("Posta in arrivo OK, ma l'invio non funziona: " + messaggio(e));
            } finally {
                try { t.close(); } catch (Exception ignored) { }
            }
            cassa.scrivi(j.toString());
            chiudiTutto();
            speciali.clear();
            anteprime.clear();
            acc = j;
            return new JSONObject(account());
        });
    }

    @JavascriptInterface
    public void esci() {
        acc = null;
        cassa.cancella();
        ex.execute(() -> {
            chiudiTutto();
            speciali.clear();
            anteprime.clear();
        });
    }

    // ---------- caselle ----------
    @JavascriptInterface
    public void cartelle(String id) { esegui(id, this::elencaCartelle); }

    private Object elencaCartelle() throws Exception {
        JSONArray arr = new JSONArray();
        speciali.clear();
        for (Folder f0 : store().getDefaultFolder().list("*")) {
            IMAPFolder f = (IMAPFolder) f0;
            if ((f.getType() & Folder.HOLDS_MESSAGES) == 0) continue;
            String tipo = "altro";
            boolean salta = false;
            String[] at = f.getAttributes();
            if (at != null) for (String a : at) {
                String l = a.toLowerCase(Locale.ROOT);
                if (l.equals("\\noselect") || l.equals("\\nonexistent")) salta = true;
                else if (l.equals("\\sent")) tipo = "inviata";
                else if (l.equals("\\drafts")) tipo = "bozze";
                else if (l.equals("\\trash")) tipo = "cestino";
                else if (l.equals("\\junk")) tipo = "indesiderata";
                else if (l.equals("\\archive")) tipo = "archivio";
                else if (l.equals("\\all")) tipo = "tutta";
                else if (l.equals("\\flagged")) tipo = "contrassegnati";
            }
            if (salta) continue;
            String full = f.getFullName(), n = full.toLowerCase(Locale.ROOT);
            if (n.equals("inbox")) tipo = "arrivo";
            else if (tipo.equals("altro")) {
                if (n.contains("sent") || n.contains("inviat")) tipo = "inviata";
                else if (n.contains("draft") || n.contains("bozz")) tipo = "bozze";
                else if (n.contains("trash") || n.contains("cestino") || n.contains("deleted")) tipo = "cestino";
                else if (n.contains("spam") || n.contains("junk") || n.contains("indesider")) tipo = "indesiderata";
                else if (n.contains("archiv")) tipo = "archivio";
            }
            if (!tipo.equals("altro")) {
                String g = speciali.get(tipo);
                if (g == null) speciali.put(tipo, full);
                else if (!g.equals(full)) tipo = "altro";
            }
            JSONObject o = new JSONObject();
            o.put("nome", full);
            o.put("vis", f.getName());
            o.put("tipo", tipo);
            if (tipo.equals("arrivo")) {
                try { o.put("nonLetti", f.getUnreadMessageCount()); } catch (Exception ignored) { }
            }
            arr.put(o);
        }
        return arr;
    }

    // ---------- elenco messaggi ----------
    @JavascriptInterface
    public void messaggi(String id, String nome, String inizio) {
        esegui(id, () -> {
            IMAPFolder f = cartella(nome);
            int tot = f.getMessageCount();
            int fine = tot - Integer.parseInt(inizio);
            int ini = Math.max(1, fine - 29);
            JSONArray l = new JSONArray();
            if (fine >= 1) {
                Message[] ms = f.getMessages(ini, fine);
                prendi(f, ms);
                for (int k = ms.length - 1; k >= 0; k--) l.put(riassunto(f, ms[k]));
            }
            JSONObject o = new JSONObject();
            o.put("totale", tot);
            o.put("lista", l);
            return o;
        });
    }

    @JavascriptInterface
    public void cerca(String id, String nome, String q) {
        esegui(id, () -> trova(nome, new OrTerm(new SearchTerm[]{new SubjectTerm(q), new FromStringTerm(q), new BodyTerm(q)})));
    }

    @JavascriptInterface
    public void filtra(String id, String nome, String tipo) {
        esegui(id, () -> trova(nome, "contrassegnati".equals(tipo)
                ? new FlagTerm(new Flags(Flags.Flag.FLAGGED), true)
                : new FlagTerm(new Flags(Flags.Flag.SEEN), false)));
    }

    private Object trova(String nome, SearchTerm t) throws Exception {
        IMAPFolder f = cartella(nome);
        Message[] r = f.search(t);
        int n = Math.min(r.length, 50);
        Message[] ms = Arrays.copyOfRange(r, r.length - n, r.length);
        prendi(f, ms);
        JSONArray l = new JSONArray();
        for (int k = ms.length - 1; k >= 0; k--) l.put(riassunto(f, ms[k]));
        return l;
    }

    private void prendi(IMAPFolder f, Message[] ms) throws MessagingException {
        FetchProfile fp = new FetchProfile();
        fp.add(FetchProfile.Item.ENVELOPE);
        fp.add(FetchProfile.Item.FLAGS);
        fp.add(FetchProfile.Item.CONTENT_INFO);
        fp.add(UIDFolder.FetchProfileItem.UID);
        f.fetch(ms, fp);
    }

    private JSONObject riassunto(IMAPFolder f, Message m) throws Exception {
        JSONObject o = new JSONObject();
        o.put("uid", String.valueOf(f.getUID(m)));
        Address[] fr = m.getFrom();
        o.put("da", nomeInd(fr));
        o.put("daEmail", emailInd(fr));
        o.put("a", nomeInd(m.getRecipients(Message.RecipientType.TO)));
        o.put("oggetto", m.getSubject() == null ? "" : m.getSubject());
        o.put("data", data(m));
        o.put("letto", m.isSet(Flags.Flag.SEEN));
        o.put("contrassegnato", m.isSet(Flags.Flag.FLAGGED));
        o.put("anteprima", anteprima(f, m));
        return o;
    }

    private long data(Message m) throws MessagingException {
        Date d = m.getSentDate();
        if (d == null) d = m.getReceivedDate();
        return d == null ? 0 : d.getTime();
    }

    private String nomeInd(Address[] a) {
        if (a == null) return "";
        StringBuilder sb = new StringBuilder();
        for (Address x : a) {
            if (sb.length() > 0) sb.append(", ");
            if (x instanceof InternetAddress) {
                InternetAddress ia = (InternetAddress) x;
                String p = ia.getPersonal();
                sb.append(p != null && !p.isEmpty() ? p : ia.getAddress());
            } else sb.append(x.toString());
        }
        return sb.toString();
    }

    private String emailInd(Address[] a) {
        if (a == null) return "";
        StringBuilder sb = new StringBuilder();
        for (Address x : a) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(x instanceof InternetAddress ? ((InternetAddress) x).getAddress() : x.toString());
        }
        return sb.toString();
    }

    private String anteprima(IMAPFolder f, Message m) {
        try {
            String k = f.getFullName() + "/" + f.getUID(m);
            String a = anteprime.get(k);
            if (a != null) return a;
            Cont c = new Cont();
            scorri(m, c);
            String t = c.testo != null ? c.testo : (c.html != null ? soloTesto(c.html) : "");
            t = t.replaceAll("\\s+", " ").trim();
            if (t.length() > 200) t = t.substring(0, 200);
            anteprime.put(k, t);
            return t;
        } catch (Exception e) {
            return "";
        }
    }

    private String soloTesto(String h) {
        return h.replaceAll("(?is)<(style|script|head|title)[^>]*>.*?</\\1>", " ")
                .replaceAll("(?s)<[^>]+>", " ")
                .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<")
                .replace("&gt;", ">").replace("&quot;", "\"").replace("&#39;", "'")
                .replaceAll("&[a-zA-Z#0-9]+;", " ");
    }

    // ---------- contenuto ----------
    private void scorri(Part p, Cont c) throws Exception {
        if (p.isMimeType("multipart/*")) {
            Multipart mp = (Multipart) p.getContent();
            for (int i = 0; i < mp.getCount(); i++) scorri(mp.getBodyPart(i), c);
            return;
        }
        if (p.isMimeType("message/rfc822")) {
            c.allegati.add(p);
            return;
        }
        String disp = null, fn = null;
        try { disp = p.getDisposition(); } catch (Exception ignored) { }
        try { fn = p.getFileName(); } catch (Exception ignored) { }
        boolean allegato = Part.ATTACHMENT.equalsIgnoreCase(disp) || fn != null;
        if (!allegato && p.isMimeType("text/plain") && c.testo == null) { c.testo = leggiTesto(p); return; }
        if (!allegato && p.isMimeType("text/html") && c.html == null) { c.html = leggiTesto(p); return; }
        if (allegato) c.allegati.add(p);
    }

    private String leggiTesto(Part p) {
        try {
            Object o = p.getContent();
            if (o instanceof String) return (String) o;
        } catch (Exception ignored) { }
        try (InputStream in = p.getInputStream()) {
            return new String(leggiTutto(in), "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private byte[] leggiTutto(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) b.write(buf, 0, n);
        return b.toByteArray();
    }

    private String nomeFile(Part p) {
        try {
            String n = p.getFileName();
            if (n != null) return MimeUtility.decodeText(n);
        } catch (Exception ignored) { }
        try { if (p.isMimeType("message/rfc822")) return "messaggio.eml"; } catch (Exception ignored) { }
        return "allegato";
    }

    @JavascriptInterface
    public void apri(String id, String nome, String uid) {
        esegui(id, () -> {
            IMAPFolder f = cartella(nome);
            Message m = msg(f, uid);
            Cont c = new Cont();
            scorri(m, c);
            if (!m.isSet(Flags.Flag.SEEN)) m.setFlag(Flags.Flag.SEEN, true);
            JSONObject o = new JSONObject();
            Address[] fr = m.getFrom();
            o.put("da", nomeInd(fr));
            o.put("daEmail", emailInd(fr));
            o.put("a", nomeInd(m.getRecipients(Message.RecipientType.TO)));
            o.put("aEmail", emailInd(m.getRecipients(Message.RecipientType.TO)));
            o.put("cc", nomeInd(m.getRecipients(Message.RecipientType.CC)));
            o.put("ccEmail", emailInd(m.getRecipients(Message.RecipientType.CC)));
            Address[] rt = m.getReplyTo();
            o.put("rispondiA", emailInd(rt != null && rt.length > 0 ? rt : fr));
            o.put("oggetto", m.getSubject() == null ? "" : m.getSubject());
            o.put("data", data(m));
            String[] mid = m.getHeader("Message-ID");
            o.put("msgid", mid != null && mid.length > 0 ? mid[0] : "");
            o.put("testo", c.testo == null ? JSONObject.NULL : c.testo);
            o.put("html", c.html == null ? JSONObject.NULL : c.html);
            JSONArray al = new JSONArray();
            for (Part p : c.allegati) {
                JSONObject a = new JSONObject();
                a.put("nome", nomeFile(p));
                a.put("dim", p.getSize());
                al.put(a);
            }
            o.put("allegati", al);
            o.put("contrassegnato", m.isSet(Flags.Flag.FLAGGED));
            return o;
        });
    }

    @JavascriptInterface
    public void allegato(String id, String nome, String uid, String indice) {
        esegui(id, () -> {
            IMAPFolder f = cartella(nome);
            Cont c = new Cont();
            scorri(msg(f, uid), c);
            Part p = c.allegati.get(Integer.parseInt(indice));
            File dir = new File(act.getCacheDir(), "allegati");
            dir.mkdirs();
            File out = new File(dir, nomeFile(p).replaceAll("[\\\\/:*?\"<>|]", "_"));
            try (InputStream in = p.getInputStream(); FileOutputStream fo = new FileOutputStream(out)) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) fo.write(buf, 0, n);
            }
            String ct = p.getContentType();
            String tipo = ct == null ? "application/octet-stream" : ct.split(";")[0].trim().toLowerCase(Locale.ROOT);
            Uri u = FileProvider.getUriForFile(act, act.getPackageName() + ".file", out);
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(u, tipo);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            act.runOnUiThread(() -> {
                try { act.startActivity(Intent.createChooser(i, "Apri con")); } catch (Exception ignored) { }
            });
            return true;
        });
    }

    // ---------- azioni ----------
    @JavascriptInterface
    public void segna(String id, String nome, String uid, String campo, String val) {
        esegui(id, () -> {
            IMAPFolder f = cartella(nome);
            msg(f, uid).setFlag("flag".equals(campo) ? Flags.Flag.FLAGGED : Flags.Flag.SEEN, "1".equals(val));
            return true;
        });
    }

    @JavascriptInterface
    public void elimina(String id, String nome, String uid) {
        esegui(id, () -> {
            IMAPFolder f = cartella(nome);
            Message m = msg(f, uid);
            if (speciali.isEmpty()) elencaCartelle();
            String c = speciali.get("cestino");
            if (c != null && !c.equals(nome)) muovi(f, m, c);
            else {
                m.setFlag(Flags.Flag.DELETED, true);
                espelli(f, m);
            }
            return true;
        });
    }

    @JavascriptInterface
    public void sposta(String id, String nome, String uid, String dest) {
        esegui(id, () -> {
            IMAPFolder f = cartella(nome);
            muovi(f, msg(f, uid), dest);
            return true;
        });
    }

    private void muovi(IMAPFolder f, Message m, String dest) throws Exception {
        Folder d = store().getFolder(dest);
        Message[] a = {m};
        try {
            f.moveMessages(a, d);
        } catch (MessagingException e) {
            f.copyMessages(a, d);
            m.setFlag(Flags.Flag.DELETED, true);
            espelli(f, m);
        }
    }

    private void espelli(IMAPFolder f, Message m) throws MessagingException {
        try { f.expunge(new Message[]{m}); } catch (MessagingException e) { f.expunge(); }
    }

    // ---------- invio ----------
    private MimeMessage costruisci(JSONObject j) throws Exception {
        MimeMessage m = new MimeMessage(sessione);
        m.setFrom(new InternetAddress(acc.optString("email"), acc.optString("nome", ""), "UTF-8"));
        indirizzi(m, Message.RecipientType.TO, j.optString("a"));
        indirizzi(m, Message.RecipientType.CC, j.optString("cc"));
        indirizzi(m, Message.RecipientType.BCC, j.optString("ccn"));
        m.setSubject(j.optString("oggetto"), "UTF-8");
        String rif = j.optString("rif", "");
        if (!rif.isEmpty()) {
            m.setHeader("In-Reply-To", rif);
            m.setHeader("References", rif);
        }
        JSONArray al = j.optJSONArray("allegati");
        if (al == null || al.length() == 0) {
            m.setText(j.optString("testo"), "UTF-8");
        } else {
            MimeMultipart mp = new MimeMultipart();
            MimeBodyPart t = new MimeBodyPart();
            t.setText(j.optString("testo"), "UTF-8");
            mp.addBodyPart(t);
            for (int k = 0; k < al.length(); k++) {
                JSONObject o = al.getJSONObject(k);
                byte[] b = Base64.decode(o.getString("dati"), Base64.DEFAULT);
                String tipo = o.optString("tipo", "");
                if (tipo.isEmpty()) tipo = "application/octet-stream";
                MimeBodyPart p = new MimeBodyPart();
                p.setDataHandler(new DataHandler(new ByteArrayDataSource(b, tipo)));
                p.setFileName(MimeUtility.encodeText(o.optString("nome", "allegato"), "UTF-8", null));
                mp.addBodyPart(p);
            }
            m.setContent(mp);
        }
        m.setSentDate(new Date());
        m.saveChanges();
        return m;
    }

    private void indirizzi(MimeMessage m, Message.RecipientType t, String s) throws Exception {
        if (s == null || s.trim().isEmpty()) return;
        m.setRecipients(t, InternetAddress.parse(s.replace(';', ','), false));
    }

    @JavascriptInterface
    public void invia(String id, String json) {
        esegui(id, () -> {
            JSONObject j = new JSONObject(json);
            store();
            MimeMessage m = costruisci(j);
            if (m.getAllRecipients() == null) throw new Exception("Inserisci almeno un destinatario.");
            Transport t = sessione.getTransport("smtp");
            try {
                t.connect(acc.optString("smtp"), acc.optInt("smtpPort", 587), utente(acc), acc.optString("password"));
                t.sendMessage(m, m.getAllRecipients());
            } catch (MessagingException e) {
                throw new Exception("Invio non riuscito: " + messaggio(e));
            } finally {
                try { t.close(); } catch (Exception ignored) { }
            }
            try {
                if (!acc.optString("smtp").contains("gmail")) {
                    if (speciali.isEmpty()) elencaCartelle();
                    String s = speciali.get("inviata");
                    if (s != null) {
                        m.setFlag(Flags.Flag.SEEN, true);
                        store().getFolder(s).appendMessages(new Message[]{m});
                    }
                }
            } catch (Exception ignored) { }
            return true;
        });
    }

    @JavascriptInterface
    public void salvaBozza(String id, String json) {
        esegui(id, () -> {
            store();
            MimeMessage m = costruisci(new JSONObject(json));
            if (speciali.isEmpty()) elencaCartelle();
            String b = speciali.get("bozze");
            if (b == null) throw new Exception("Cartella Bozze non trovata.");
            m.setFlag(Flags.Flag.DRAFT, true);
            m.setFlag(Flags.Flag.SEEN, true);
            store().getFolder(b).appendMessages(new Message[]{m});
            return true;
        });
    }

    // ---------- interfaccia ----------
    @JavascriptInterface
    public void permettiRemoti(boolean b) { remoti = b; }

    @JavascriptInterface
    public boolean temaScuro() {
        return (act.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
    }

    @JavascriptInterface
    public void barra(String colore, boolean scuro) { act.runOnUiThread(() -> act.barra(colore, scuro)); }

    @JavascriptInterface
    public void apriLink(String u) { act.runOnUiThread(() -> act.apriEsterno(u)); }

    @JavascriptInterface
    public String mailtoIniziale() {
        String m = act.mailto;
        act.mailto = null;
        return m == null ? "" : m;
    }
}
